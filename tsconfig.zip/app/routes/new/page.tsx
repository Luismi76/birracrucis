import RouteEditor from "@/components/RouteEditor";

// Forzar renderizado dinámico (no estático)
export const dynamic = "force-dynamic";

export default function NewRoutePage() {
    return <RouteEditor />;
}
