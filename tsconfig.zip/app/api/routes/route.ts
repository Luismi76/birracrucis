// app/api/routes/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth-helpers";
import { nanoid } from "nanoid";
import { prisma } from "@/lib/prisma";
import { rateLimit, getClientIdentifier, RATE_LIMIT_CONFIGS, rateLimitExceededResponse } from "@/lib/rate-limit";
import { createRouteSchema } from "@/lib/validations/route";

// Genera un código de invitación único (8 caracteres, alfanumérico)
function generateInviteCode(): string {
  return nanoid(8).toUpperCase();
}

export async function POST(req: NextRequest) {
  // Rate limiting - endpoint de escritura (crear rutas)
  const clientId = getClientIdentifier(req);
  const rateLimitResult = await rateLimit(`routes:create:${clientId}`, RATE_LIMIT_CONFIGS.write);
  if (!rateLimitResult.success) {
    return rateLimitExceededResponse(rateLimitResult.reset);
  }

  try {
    // Obtener usuario actual (opcional - permite crear rutas sin autenticación)
    const auth = await getCurrentUser(req);
    let userId: string | null = null;

    // Solo usuarios autenticados (no guests) pueden ser creadores
    if (auth.ok && auth.user.type === "user") {
      userId = auth.user.id;
    }

    const json = await req.json();

    // VALIDACIÓN CON ZOD
    const validationResult = createRouteSchema.safeParse(json);

    if (!validationResult.success) {
      // Formatear errores de Zod para devolver mensaje legible
      const errorMessages = validationResult.error.errors.map(err => `${err.path.join('.')}: ${err.message}`).join('\n');
      return NextResponse.json(
        { ok: false, error: `Datos inválidos:\n${errorMessages}` },
        { status: 400 }
      );
    }

    const body = validationResult.data;
    const { name, date, stops, startMode, startTime, hasEndTime, endTime } = body;

    // Las plantillas NO tienen inviteCode - solo las ediciones
    const route = await prisma.route.create({
      data: {
        name,
        date: date || null,
        creatorId: userId || null,
        // Public visibility
        isPublic: body.isPublic,
        isDiscovery: body.isDiscovery,
        // Template system - new routes are templates by default
        isTemplate: true,
        // Campos de tiempo
        startMode: startMode,
        startTime: startTime || null,
        hasEndTime: hasEndTime,
        endTime: endTime || null,
        stops: {
          create: stops.map((s, index) => ({
            name: s.name,
            address: s.address ?? "",
            lat: s.lat,
            lng: s.lng,
            order: index,
            plannedRounds: s.plannedRounds,
            maxRounds: s.maxRounds,
            googlePlaceId: s.googlePlaceId,
            stayDuration: s.stayDuration,
          })),
        },
        // Si hay usuario, agregarlo como participante automáticamente
        ...(userId && {
          participants: {
            create: {
              userId,
            },
          },
        }),
      },
      include: { stops: true },
    });

    // Si es modo descubrimiento, crear automáticamente una EDICIÓN ACTIVA
    if (body.isDiscovery && userId) {
      // Crear código de invitación para la edición
      let editionInviteCode = generateInviteCode();
      let attCheck = 0;
      while (attCheck < 5) {
        const temp = await prisma.route.findUnique({ where: { inviteCode: editionInviteCode } });
        if (!temp) break;
        editionInviteCode = generateInviteCode();
        attCheck++;
      }

      const activeEdition = await prisma.route.create({
        data: {
          name: route.name, // Mismo nombre que la plantilla
          date: new Date(), // Fecha actual
          creatorId: userId,
          startMode: "manual",
          isTemplate: false,
          templateId: route.id,
          inviteCode: editionInviteCode,
          status: "active", // Ya está activa o lista para empezar? "pending" es mejor si startMode=manual, pero el usuario quiere empezar ya. Pongamos "pending" para que le de a "Empezar" en la UI.
          // Copiar paradas (en discovery suele ser solo 1 inicial)
          stops: {
            create: route.stops.map(s => ({
              name: s.name,
              address: s.address,
              lat: s.lat,
              lng: s.lng,
              order: s.order,
              plannedRounds: s.plannedRounds,
              maxRounds: s.maxRounds,
              googlePlaceId: s.googlePlaceId,
              stayDuration: s.stayDuration
            }))
          },
          participants: {
            create: { userId }
          }
        }
      });

      // Devolver la edición ACTIVA en lugar de la plantilla
      return NextResponse.json({ ok: true, route: activeEdition, isDiscoveryRedirect: true }, { status: 201 });
    }

    // Si el usuario marcó "Crear edición ahora", crear plantilla + edición en un solo paso
    if (body.createEditionNow && userId) {
      let editionInviteCode = generateInviteCode();
      let attCheck = 0;
      while (attCheck < 5) {
        const temp = await prisma.route.findUnique({ where: { inviteCode: editionInviteCode } });
        if (!temp) break;
        editionInviteCode = generateInviteCode();
        attCheck++;
      }

      // Validar fecha: usar la del body (ya parseada por Zod) si existe, sino usar hoy
      const editionDate = date || new Date();

      const edition = await prisma.route.create({
        data: {
          name: route.name,
          date: editionDate,
          creatorId: userId,
          startMode: startMode,
          startTime: startTime || null,
          hasEndTime: hasEndTime,
          endTime: endTime || null,
          isTemplate: false,
          templateId: route.id,
          inviteCode: editionInviteCode,
          status: "pending",
          potEnabled: body.potEnabled,
          potAmountPerPerson: body.potAmountPerPerson,
          stops: {
            create: route.stops.map(s => ({
              name: s.name,
              address: s.address,
              lat: s.lat,
              lng: s.lng,
              order: s.order,
              plannedRounds: s.plannedRounds,
              maxRounds: s.maxRounds,
              googlePlaceId: s.googlePlaceId,
              stayDuration: s.stayDuration
            }))
          },
          participants: {
            create: { userId }
          }
        },
        include: { stops: true }
      });

      // Devolver plantilla + edición creada
      return NextResponse.json({ ok: true, route, edition }, { status: 201 });
    }

    return NextResponse.json({ ok: true, route }, { status: 201 });
  } catch (error) {
    console.error("Error en POST /api/routes:", error);
    return NextResponse.json(
      {
        ok: false,
        error: (error as Error).message,
      },
      { status: 500 }
    );
  }
}
